AddCSLuaFile()

ENT.PrintName = "F1 Grenade"
ENT.Category  = "Call of Pripyat - Miscellaneous"

ENT.Base  = "cop_grenade_base"
ENT.Type  = "anim"
ENT.Model = "models/wick/weapons/stalker/stcopwep/w_f1_model_stcop.mdl"

ENT.Radius = 400
ENT.Damage = 250

ENT.Sound = "weapons/stalker_cop/grenade1.wav"