AddCSLuaFile()

ENT.PrintName = "RGD-5 Grenade"
ENT.Category  = "Call of Pripyat - Miscellaneous"

ENT.Base  = "cop_grenade_base"
ENT.Type  = "anim"
ENT.Model = "models/wick/weapons/stalker/stcopwep/w_rgd_model_stcop.mdl"

ENT.Radius = 350
ENT.Damage = 200

ENT.Sound = "weapons/stalker_cop/grenade1.wav"