FACTION.name = "Полковник | 21-й"
FACTION.desc = "21-я — Галактическая пехота."
FACTION.color = Color(92, 18, 76)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/21st/marine_officer.mdl",
}
FACTION.weapons = {
        "tg_republic_dual_dc17",
        "tg_explosif_plx1"
}
FACTION_GALPCOL = FACTION.index