FACTION.name = "Лейтенант | Корусантская Гвардия | Медик"
FACTION.desc = "Корусантская Гвардия."
FACTION.color = Color(204, 21, 8)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/cg/medic_officer.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dc17",
	"tg_explosif_nade_bacta"
}
FACTION_MLCGMEDLT = FACTION.index