FACTION.name = "Солдат | 104-й | ARF"
FACTION.desc = "104-й — Батальон."
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/104th/arf_trooper.mdl",
}
FACTION.weapons = {
        "tg_republic_dc15s"
}
FACTION_STARF = FACTION.index