FACTION.name = "САД | Дроид-коммандос"
FACTION.desc = "САД - Сепаратийская армия дройдов."
FACTION.color = Color(128, 128, 0)
FACTION.models = {
	"models/sally/tkaro/bx_commando_droid.mdl"
}
FACTION.weapons = {
	"tg_separatist_e5bx",
        "tg_separatist_sg6"
}
FACTION.isDefault = false
FACTION.isPublic = true
FACTION_SADBX = FACTION.index
function FACTION:onSpawn(client)
    client:SetHealth(200)
    client:SetRunSpeed(400)
end