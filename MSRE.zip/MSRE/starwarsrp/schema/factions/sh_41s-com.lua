﻿FACTION.name = "Коммандер | 41-й"
FACTION.desc = "41-й элитный корпус"
FACTION.color = Color(0, 100, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/41st/officer.mdl"
}
FACTION.weapons = {
        "tg_republic_dc15s",
	"tg_republic_dual_dc17",
        "tg_republic_dual_dc17"
}
FACTION_ELBATCOM = FACTION.index