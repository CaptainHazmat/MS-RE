FACTION.name = "Капитан | ARC"
FACTION.desc = "Элитный республиканский коммандос"
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/Captain_arc.mdl",
}
FACTION.weapons = {
        "tg_republic_westarm5",
	"tg_republic_dc17s",
        "tg_explosif_nade_thermal"
}
FACTION_ARCCPT = FACTION.index
function FACTION:onSpawn(client)
    client:SetHealth(150)
end