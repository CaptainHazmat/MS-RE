﻿FACTION.name = "Пилот | Республиканский флот | AT-TE"
FACTION.desc = "Республиканский флот"
FACTION.color = Color(32, 109, 232)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/pilots/pilot_atte.mdl"
}
FACTION.weapons = {	
	"tg_republic_dc15s"
}
FACTION_RFATTE = FACTION.index