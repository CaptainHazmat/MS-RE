FACTION.name = "Майор | 327-й"
FACTION.desc = "327-й — Звёздный корпус."
FACTION.color = Color(216, 227, 9)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/327th/deviss.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15a",
        "tg_republic_dual_dc17",
        "tg_explosif_nade_dioxis"
}
FACTION_STPZCORMAJ = FACTION.index