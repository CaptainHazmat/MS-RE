FACTION.name = "Солдат | 104-й"
FACTION.desc = "104-й — Батальон."
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/104th/trooper.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s"
}
FACTION_STPV = FACTION.index