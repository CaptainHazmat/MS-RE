﻿FACTION.name = "Сержант | 41-й | Зелёная рота"
FACTION.desc = "41-й — корпус."
FACTION.color = Color(0, 100, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/41st/gree.mdl"
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_explosif_nade_thermal"
}
FACTION_ELBATSGTG = FACTION.index