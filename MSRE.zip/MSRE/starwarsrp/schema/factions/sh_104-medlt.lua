FACTION.name = "Лейтенант | 104-й | Медик"
FACTION.desc = "104-й — Батальон."
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/104th/medic_officer.mdl",
}
FACTION.weapons = {
	"rw_sw_dc15s",
        "rw_sw_dc17",
	"rw_sw_nade_bacta"
}
FACTION_STMEDOF = FACTION.index