FACTION.name = "Специалист | 501-й"
FACTION.desc = "501-й — Легион."
FACTION.color = Color(9, 13, 227)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/501st/arf_trooper.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15x",
        "weapon_shield_activator"
}
FACTION_LEGSPEC = FACTION.index
function FACTION:onSpawn(client)
    client:SetRunSpeed(360)
end