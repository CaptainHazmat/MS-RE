﻿FACTION.name = "Инженер | Республиканский флот"
FACTION.desc = "Республиканский флот"
FACTION.color = Color(32, 109, 232)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/pilots/pilot_broadside.mdl"
}
FACTION.weapons = {	
	"tg_republic_dp23",
        "weapon_lvsrepair"
}
FACTION_RFING = FACTION.index