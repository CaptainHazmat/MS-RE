FACTION.name = "Лейтенант | 501-й | Медик"
FACTION.desc = "501-й — Легион."
FACTION.color = Color(9, 13, 227)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/501st/Medic_Officer.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dc17",
	"tg_explosif_nade_bacta"
}
FACTION_LEGMEDLT = FACTION.index