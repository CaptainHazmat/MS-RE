﻿FACTION.name = "Пилот | Республиканский флот"
FACTION.desc = "Республиканский флот"
FACTION.color = Color(32, 109, 232)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/pilots/pilot_plain.mdl"
}
FACTION.weapons = {	
	"tg_republic_dc15s"
}
FACTION_RFP = FACTION.index