FACTION.name = "САД | Дроид-снайпер"
FACTION.desc = "САД - Сепаратийская армия дройдов."
FACTION.color = Color(128, 128, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/player/b1battledroids/b1_base_camo.mdl"
}
FACTION.weapons = {
	"tg_separatist_e5s" 
}
FACTION_SADBCAM = FACTION.index