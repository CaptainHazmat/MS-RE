FACTION.name = "Капитан | Корусантская Гвардия"
FACTION.desc = "Корусантская Гвардия."
FACTION.color = Color(204, 21, 8)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/cg/officer.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dc17"
}
FACTION_TCGCPT = FACTION.index