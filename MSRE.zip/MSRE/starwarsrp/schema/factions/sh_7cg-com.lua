FACTION.name = "Коммандер | Корусантская Гвардия"
FACTION.desc = "Корусантская Гвардия."
FACTION.color = Color(204, 21, 8)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/cg/fox.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dual_dc17"
}
FACTION_OCGCOM = FACTION.index