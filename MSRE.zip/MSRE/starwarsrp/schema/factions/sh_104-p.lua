FACTION.name = "Пилот | 104-й"
FACTION.desc = "104-й батальон."
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/104th/pilot.mdl"
}
FACTION.weapons = {	
	"tg_republic_dc15s",
        "weapon_lvsrepair"
}
FACTION_DSPPDSG = FACTION.index