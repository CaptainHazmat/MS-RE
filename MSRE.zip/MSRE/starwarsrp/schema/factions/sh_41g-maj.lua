﻿FACTION.name = "Майор | 41-й | Зелёная рота"
FACTION.desc = "41-й — корпус."
FACTION.color = Color(0, 100, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/41st/green_company_officer.mdl"
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dual_dc17",
        "tg_explosif_nade_thermal"
}
FACTION_ELBATMAJG = FACTION.index