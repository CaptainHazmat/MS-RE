FACTION.name = "ВАР | Дроид B1 | Тренировочный"
FACTION.desc = "ВАР - Великая армия Республики."
FACTION.color = Color(35, 131, 204)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/player/b1battledroids/b1_base_training.mdl"
}
FACTION.weapons = {
	"tg_republic_trd_dc15a" 
}
FACTION_WARTREN = FACTION.index
function FACTION:onSpawn(client)
    client:SetRunSpeed(300)
end