FACTION.name = "Пилот | 501-й"
FACTION.desc = "501-й — Легион."
FACTION.color = Color(9, 13, 227)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/pilots/pilot_hawk.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "weapon_lvsrepair"
}
FACTION_LEGP = FACTION.index