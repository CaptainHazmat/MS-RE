FACTION.name = "Лейтенант | 212-й | Медик"
FACTION.desc = "212-й — Штурмовой батальон."
FACTION.color = Color(227, 118, 9)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/212th/medic_officer.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dc17",
	"tg_explosif_nade_bacta"
}
FACTION_HBATMEDLT = FACTION.index