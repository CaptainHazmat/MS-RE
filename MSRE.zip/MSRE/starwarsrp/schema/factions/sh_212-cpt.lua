FACTION.name = "Капитан | 212-й"
FACTION.desc = "212-й — Штурмовой батальон."
FACTION.color = Color(227, 118, 9)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/212th/officer.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dual_dc17",
        "tg_explosif_nade_thermal"
}
FACTION_HBATCPT = FACTION.index