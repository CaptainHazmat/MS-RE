FACTION.name = "САД | Дроид-пилот"
FACTION.desc = "САД - Сепаратийская армия дройдов."
FACTION.color = Color(128, 128, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/player/b1battledroids/b1_base_pilot.mdl"
}
FACTION.weapons = {
	"tg_separatist_se14cs"
}
FACTION_SADBP = FACTION.index
function FACTION:onSpawn(client)
    client:SetRunSpeed(300)
end