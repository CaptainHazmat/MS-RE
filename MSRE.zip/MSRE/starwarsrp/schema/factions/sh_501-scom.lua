FACTION.name = "Старший коммандер | 501-й"
FACTION.desc = "501-й — Легион."
FACTION.color = Color(9, 13, 227)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/501st/501st_rex.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15le",
        "tg_republic_dual_dc17",
        "tg_explosif_nade_impact"
}
FACTION_LEGSCOM = FACTION.index