FACTION.name = "Маршал коммандер | 104-й"
FACTION.desc = "104-й — Батальон."
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/104th/coyote_leader.mdl",
}
FACTION.weapons = {
        "tg_republic_dc15s",
	"tg_explosif_rps6",
        "tg_explosif_nade_incendiary"
}
FACTION_STMCOERMMCOM = FACTION.index