FACTION.name = "САД | Дроид-командир"
FACTION.desc = "САД - Сепаратийская армия дройдов."
FACTION.color = Color(128, 128, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/player/b1battledroids/b1_base_com.mdl"
}
FACTION.weapons = {
	"tg_separatist_e5",
        "tg_separatist_rg4d"
}
FACTION_SADBCOM = FACTION.index
function FACTION:onSpawn(client)
    client:SetRunSpeed(300)
end