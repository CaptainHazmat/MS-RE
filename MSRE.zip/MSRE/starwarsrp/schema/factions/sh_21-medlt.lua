FACTION.name = "Лейтенант | 21-й | Медик"
FACTION.desc = "21-я — Галактическая пехота."
FACTION.color = Color(92, 18, 76)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/21st/marine_medic_officer.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15a",
        "tg_republic_dc17",
        "tg_explosif_nade_bacta"
}
FACTION_GALPMEDLT = FACTION.index