﻿FACTION.name = "Солдат | 41-й"
FACTION.desc = "41-й элитный корпус"
FACTION.color = Color(0, 100, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/41st/trooper.mdl"
}
FACTION.weapons = {
	"tg_republic_dc15a"
}
FACTION_ELBATPV = FACTION.index