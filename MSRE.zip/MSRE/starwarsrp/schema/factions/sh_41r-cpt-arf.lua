﻿FACTION.name = "Капитан | 41-й | Взвод рейнджеров | ARF"
FACTION.desc = "41-й — Разведывательный корпус."
FACTION.color = Color(0, 100, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/41st/arf_officer.mdl"
}
FACTION.weapons = {
	"tg_republic_dc15x",
	"tg_republic_dual_dc17",
        "tg_explosif_nade_thermal"
}
FACTION_ELBATCPTRARF = FACTION.index
function FACTION:onSpawn(client)
    client:SetRunSpeed(360)
end