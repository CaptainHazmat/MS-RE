FACTION.name = "Поддержка | 501-й"
FACTION.desc = "501-й — Легион."
FACTION.color = Color(9, 13, 227)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/501st/501st_officer.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15a",
        "tg_explosif_pinglauncher",
        "tg_explosif_nade_smoke",
        "tg_explosif_nade_impact",
        "weapon_squadshield_arm"
}
FACTION_LEGSUP = FACTION.index