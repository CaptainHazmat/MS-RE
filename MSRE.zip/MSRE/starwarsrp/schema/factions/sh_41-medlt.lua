﻿FACTION.name = "Лейтенант | 41-й | Медик"
FACTION.desc = "41-й — Корпус."
FACTION.color = Color(0, 100, 0)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/41st/green_company_medic_officer.mdl"
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "tg_republic_dc17",
	"tg_explosif_nade_bacta"
}
FACTION_ELBATMEDLT = FACTION.index