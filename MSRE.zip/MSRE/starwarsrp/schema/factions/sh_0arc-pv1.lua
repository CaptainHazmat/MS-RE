FACTION.name = "Солдат | ARC"
FACTION.desc = "Элитный республиканский коммандос"
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/trooper_arc.mdl",
}
FACTION.weapons = {
        "tg_republic_dual_dc17",
        "tg_explosif_nade_thermal"
}
FACTIOWWN_ARCPV = FACTION.index
function FACTION:onSpawn(client)
    client:SetHealth(150)
end