FACTION.name = "Пилот | 21-й"
FACTION.desc = "21-я — Галактическая пехота."
FACTION.color = Color(92, 18, 76)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/21st/pilot.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15s",
        "weapon_lvsrepair"
}
FACTION_GALPP = FACTION.index