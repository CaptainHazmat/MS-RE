﻿FACTION.name = "Сержант | 11-я эскадрилья"
FACTION.desc = "Республиканский флот"
FACTION.color = Color(252, 211, 5)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/pilot.mdl"
}
FACTION.weapons = {	
	"tg_republic_dc15s",
	"tg_republic_dc17",
        "weapon_lvsrepair"
}
FACTION_ESKSGT = FACTION.index