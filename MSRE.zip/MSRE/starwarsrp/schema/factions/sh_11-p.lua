﻿FACTION.name = "Пилот | 11-я эскадрилья"
FACTION.desc = "Республиканский флот"
FACTION.color = Color(252, 211, 5)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/pilots/pilot_standard.mdl"
}
FACTION.weapons = {	
	"tg_republic_dc15s",
        "weapon_lvsrepair"
}
FACTION_ESKP = FACTION.index