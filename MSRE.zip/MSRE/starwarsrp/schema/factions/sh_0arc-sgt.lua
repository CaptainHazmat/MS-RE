FACTION.name = "Сержант | ARC"
FACTION.desc = "Элитный республиканский коммандос"
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/sergeant_arc.mdl",
}
FACTION.weapons = {
        "tg_republic_dc15s",
	"tg_republic_dual_dc17",
        "tg_explosif_nade_thermal"
}
FACTION_ARCSGT = FACTION.index
function FACTION:onSpawn(client)
    client:SetHealth(150)
end