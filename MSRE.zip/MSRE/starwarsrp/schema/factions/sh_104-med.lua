FACTION.name = "Солдат | 104-й | Медик"
FACTION.desc = "104-й — Батальон."
FACTION.color = Color(119, 136, 153)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/104th/medic.mdl",
}
FACTION.weapons = {
	"rw_sw_dc15s",
	"rw_sw_nade_bacta"
}
FACTION_STMED = FACTION.index