FACTION.name = "Капрал | 21-й"
FACTION.desc = "21-я — Галактическая пехота."
FACTION.color = Color(92, 18, 76)
FACTION.isDefault = false
FACTION.isPublic = true
FACTION.models = {
	"models/aussiwozzi/phase1clones/21st/marine_trooper.mdl",
}
FACTION.weapons = {
	"tg_republic_dc15a"
}
FACTION_GALPCPL = FACTION.index