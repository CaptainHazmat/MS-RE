PLUGIN.name = "NPC Tool 2 saver"
PLUGIN.author = "Tium"
PLUGIN.desc = "Простой плагин, позволяющий сохранять спавнеры нпс"

nut.util.include("sv_plugin.lua")


function PLUGIN:SaveData()
	local data = {}

	for k, v in ipairs(ents.FindByClass("obj_npcspawner")) do
		data[#data + 1] = {
		pos = v:GetPos(),
		class = v:GetNPCClass(), 
		sdelay = v:GetSpawnDelay(),
		mnpc = v:GetMaxNPCs(),
		tnpc = v:GetTotalNPCs(),
		start = v:GetStartOn(),
		fade = v:GetFadeTime(),
		}
	end

	self:setData(data)
end

function PLUGIN:LoadData()
	local data = self:getData()
	for k, v in ipairs(data) do
		local spawner = ents.Create("obj_npcspawner")
		spawner:SetPos(v.pos)
		spawner:SetNPCClass(v.class) 
		spawner:SetSpawnDelay(v.sdelay)
		spawner:SetMaxNPCs(v.mnpc)
		spawner:SetTotalNPCs(v.tnpc)
		spawner:SetStartOn(v.start)
		spawner:SetFadeTime(v.fade)
		spawner:Spawn()
		spawner:Activate()
		spawner:ShowEffects(false) 
	end
end
