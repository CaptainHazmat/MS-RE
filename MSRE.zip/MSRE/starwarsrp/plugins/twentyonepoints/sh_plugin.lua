﻿local PLUGIN = PLUGIN

PLUGIN.name = "Twenty One Point"
PLUGIN.author = "Kek1ch&DrodA"
PLUGIN.desc = "Если вам нужно 21 очко в 1000 строк, то пишите vk.com/mamonov1337"

nut.util.include("sv_plugin.lua")

