PLUGIN.name = "Talking NPCs"
PLUGIN.author = "Black Tea (NS 1.0), Neon (NS 1.1)"
PLUGIN.desc = "Adding talking NPCs."
PLUGIN.chatDelay = { min = .5, max = 1 }
PLUGIN.defaultDialogue = {
	npc = {
		["_start"] = "Приветствую, брат.",
		["test1"] = "Для Республики настали сложные времена.",
	},
	player = {
		["quit"] = "Бывай!",
		["test1"] = "Что нового?",
	},
}

nut.util.include("sv_plugin.lua")