PLUGIN.name = "Mission Tasks"
PLUGIN.author = "Tium"
PLUGIN.desc = "Можно создавать задачи на миссию. Для админов и ивентологов"

nut.util.include("sv_plugin.lua")

Mission = Mission or {}
Mission.data = Mission.data or {}
Mission.data.tasks = Mission.data.tasks or {} 
Mission.data.name = Mission.data.name or "Нет Заданий"
Mission.data.failed = Mission.data.failed or 0


if CLIENT then
	net.Receive("UpdateMissionTasks",function()
		Mission.data = net.ReadTable()
	end)
	
	local Delay = 0
	
	function PLUGIN:PlayerButtonDown( ply, button )
		if button == 18 and Delay <= CurTime() then
			Delay = CurTime() + 0.1
			if  Mission.data.name != "Нет Заданий" or #Mission.data.tasks >= 1 then
				if (IsValid(nut.gui.tasks)) then
					nut.gui.tasks:Remove()
				else
					vgui.Create("nutTasksBox")
				end
			end
			
		end
	end
	
	function PLUGIN:OnContextMenuOpen()
		if LocalPlayer():IsAdmin() then
			vgui.Create("nutMissionMenu")
		end
	end
	
	function PLUGIN:OnContextMenuClose()
		if (IsValid(nut.gui.MissionMenu)) then
			nut.gui.MissionMenu:Remove()
		end
	end
end

nut.command.add("taskdel", {
	adminOnly = true,
	syntax = "<number task>",
    onRun = function(client, arguments)
		local num = tonumber(arguments[1])
		table.remove( Mission.data.tasks, num )
		Mission:CheckStatus()
		Mission:UpdateClients()
    end
})

nut.command.add("taskadd", {
	adminOnly = true,
	syntax = "<sting name> <number need_progress>",
    onRun = function(client, arguments)
		if #Mission.data.tasks == 10 then 
			client:notify("Ограничение в 10 задач!")
			return false
		end
		local name = arguments[1]
		local progressneeded = tonumber(arguments[2]) or 1
		table.insert( Mission.data.tasks, #Mission.data.tasks + 1, {name = name, progress = 0, progressneeded = progressneeded} )
		Mission:CheckStatus()
		Mission:UpdateClients()
    end
})

nut.command.add("taskgive", {
	adminOnly = true,
	syntax = "<number task> <number amount>",
    onRun = function(client, arguments)
		local task = tonumber(arguments[1]) or 1
		local amount = tonumber(arguments[2]) or 1 
		Mission:GiveProgress(task, amount)
    end
})

nut.command.add("tasktake", {
	adminOnly = true,
	syntax = "<number task> <number amount>",
    onRun = function(client, arguments)
		local task = tonumber(arguments[1]) or 1
		local amount = tonumber(arguments[2]) or 1 
		Mission:TakeProgress(task, amount)
    end
})

nut.command.add("taskcompall", {
	adminOnly = true,
    onRun = function(client)
		Mission:CompleteAlltasks()
    end
})

nut.command.add("taskcomplete", {
	adminOnly = true,
	syntax = "<number task>",
    onRun = function(client, arguments)
		local task = tonumber(arguments[1]) or 1
		Mission:CompleteTask(task)
    end
})

nut.command.add("taskname", {
	adminOnly = true,
	syntax = "<number task> <string name>",
    onRun = function(client, arguments)
		local task = tonumber(arguments[1]) or 1
		local name = arguments[2]
		if !name then return false end
		Mission:EditName(task, name)
    end
})

nut.command.add("taskpneed", {
	adminOnly = true,
	syntax = "<number task> <number amount>",
    onRun = function(client, arguments)
		local task = tonumber(arguments[1]) or 1
		local amount = tonumber(arguments[2]) or 1 
		Mission:EditPNeeded(task, amount)
    end
})

nut.command.add("missionstatus", {
	adminOnly = true,
    onRun = function(client, arguments)
		local task = tonumber(arguments[1]) or 0
		if task > 2 then task = 0 end
		Mission.data.failed = task
		Mission:UpdateClients()
    end
})

nut.command.add("missionclear", {
	adminOnly = true,
    onRun = function(client)
		Mission.data =  {}
		Mission.data.tasks = {} 
		Mission.data.name =  "Нет Заданий"
		Mission.data.failed =  0
		Mission:UpdateClients()
    end
})

nut.command.add("missionname", {
	adminOnly = true,
	syntax = "<string name>",
    onRun = function(client, arguments)
		local name = arguments[1]
		Mission.data.name = name
		Mission:UpdateClients()
    end
})