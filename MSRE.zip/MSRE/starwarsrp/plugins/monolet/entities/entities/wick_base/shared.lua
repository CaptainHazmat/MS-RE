ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity" 
ENT.Category 		= "Doors"  
ENT.PrintName	= "Doors Base"
ENT.Author		= "WickRabbit" 
ENT.Contact		= "" 
 
ENT.Spawnable		= false --Spawnable?
ENT.AdminSpawnable	= false --If spawnable, is it admin only?
ENT.AutomaticFrameAdvance = true   
 
