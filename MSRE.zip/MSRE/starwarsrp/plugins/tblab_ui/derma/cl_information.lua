local menu_12 = "menu_16"
local menu_18 = "menu_18"

local PANEL = {}
	function PANEL:Init()
		if (IsValid(nut.gui.info)) then
			nut.gui.info:Remove()
		end

		nut.gui.info = self
		
		local suppress = hook.Run("CanCreateCharInfo", self)

		if (!suppress or (suppress and !suppress.all)) then
		
			self.back = self:Add("DPanel")
			self.back:Dock(FILL)
			self.back:DockMargin(ScrW()/12, 0, ScrW()/12, 0)
			self.back.Paint = function(s,w,h)
				
				surface.SetDrawColor(Color(75, 75, 75, 255))
				surface.DrawRect(0, ScrH()/16 + 68, w, 3)
			end
			
			if (!suppress or !suppress.name) then
			
				self.back.namepanel = self.back:Add("DPanel")
				self.back.namepanel:Dock(TOP)
				self.back.namepanel:DockMargin(0, ScrH()/16, ScrW()*0.55, 20)
				self.back.namepanel:SetTall(58)
				self.back.namepanel.Paint = function(s,w,h)
					surface.SetDrawColor(255, 0, 0, 50)
					surface.DrawRect(0, 0, w, h)
							
				end
				
				self.back.namepanel.Cname = self.back.namepanel:Add("DLabel")
				self.back.namepanel.Cname:SetFont("menu_40") -- 30
				self.back.namepanel.Cname:SetTextColor(color_white)
				self.back.namepanel.Cname:SetExpensiveShadow(1, Color(0, 0, 0, 150))
			end
			
			if (!suppress or !suppress.model) then			
				self.back.model = self.back:Add("nutModelPanel")
				self.back.model:Dock(FILL)
				self.back.model:SetFOV(10)
				self.back.model:DockMargin(0, 0, ScrW()*0.55, ScrH()*0.25 ) --14/16
				self.back.model.enableHook = false
				self.back.model.copyLocalSequence = false
			end		
			
			self.back.up = self.back:Add("DPanel")
			self.back.up:Dock(FILL)
			self.back.up:DockMargin(ScrW()*0.3, 0, 0, ScrH()*0.62)
			self.back.up.Paint = function(s,w,h)
				surface.SetDrawColor(Color(255, 255, 255, 255))
				surface.SetMaterial(Material("hud/LINE_desc_2.png"))
				surface.DrawTexturedRect(2, 0, 2, h)
			end
			
			if (!suppress or !suppress.experience) then
				self.back.up.experience = self.back.up:Add("DLabel")
				self.back.up.experience:Dock(TOP)
				self.back.up.experience:SetFont("menu_30")
				self.back.up.experience.xp = 0
				self.back.up.experience.lvl = 0
				self.back.up.experience:SetTextColor(Color(255,0,0,210))
				self.back.up.experience:SetExpensiveShadow(1, Color(0, 0, 0, 150))
				self.back.up.experience:DockMargin(10, 10, 0, 0)
				self.back.up.experience:SetText("Ранг: "..self.back.up.experience.lvl .."  |  ".. math.Round( (self.back.up.experience.xp/((self.back.up.experience.lvl+1)*1000))*100, 0).."%")
			end
			
			if (!suppress or !suppress.money) then
				self.back.up.money = self.back.up:Add("DLabel")
				self.back.up.money:Dock(TOP)
				self.back.up.money:SetFont(menu_18)
				self.back.up.money:SetTextColor(color_white)
				self.back.up.money:SetExpensiveShadow(1, Color(0, 0, 0, 150))
				self.back.up.money:DockMargin(10, 10, 0, 0)
			end
			
			if (!suppress or !suppress.faction) then
				self.back.up.faction = self.back.up:Add("DLabel")
				self.back.up.faction:Dock(TOP)
				self.back.up.faction:SetFont("menu_40")
				self.back.up.faction:SetTextColor(color_white)
				self.back.up.faction:SetExpensiveShadow(1, Color(0, 0, 0, 150))
				self.back.up.faction:DockMargin(10, 10, 0, 0)
			end
			
			self.back.middle = self.back:Add("DPanel")
			self.back.middle:Dock(FILL)
			self.back.middle:DockMargin(ScrW()*0.3, ScrH()*0.15, 0, ScrH()*0.25)
			self.back.middle.Paint = function(s,w,h)
				surface.SetDrawColor(Color(255, 255, 255, 255))
				surface.SetMaterial(Material("hud/LINE_desc_2.png"))
				surface.DrawTexturedRect(2, 0, 2, h)
			end
			
			if (!suppress or !suppress.desc) then
				
				self.back.middle.textentry = self.back.middle:Add("DTextEntry")
				self.back.middle.textentry:SetFont("menu_20")
				self.back.middle.textentry:SetTextColor( color_white )
				self.back.middle.textentry:SetMultiline(true)
				self.back.middle.textentry:SetEditable(true)
				self.back.middle.textentry:Dock(FILL)
				self.back.middle.textentry:DockMargin(10, 0, 0, 0)	
				self.back.middle.textentry:SetPaintBackgroundEnabled(false)
				self.back.middle.textentry:SetPaintBackground(false)
				self.back.middle.textentry:SetEnterAllowed(false)
				self.back.middle.textentry:SetDrawLanguageID( false )
			end
			
			if (!suppress or !suppress.attrib) then
			
				self.back.attribspanel = self.back:Add("DPanel")
				self.back.attribspanel:Dock(FILL)
				self.back.attribspanel:DockMargin(0, ScrH()*0.52, 0, 10 )
				
				self.back.attribspanel.attribs = self.back.attribspanel:Add("DScrollPanel")
				self.back.attribspanel.attribs:Dock(FILL)
			end
		end

		hook.Run("CreateCharInfo", self)
	end

	function PANEL:setup()
		local char = LocalPlayer():getChar()
		if (self.back.middle.textentry) then
			self.back.middle.textentry:SetText(char:getDesc())
			self.back.middle.textentry.OnLoseFocus = function(this)
				nut.command.send("charsetdesc", this:GetText())
			end
			self.back.middle.textentry.OnKeyCodeTyped = function(this, key)
				if key == 64 then
					nut.command.send("charsetdesc", this:GetText())
				end
			end
		end

		if (self.back.namepanel.Cname) then
			self.back.namepanel.Cname:SetText(LocalPlayer():Name())
			self.back.namepanel.Cname:Dock(FILL)
			self.back.namepanel.Cname:SizeToContents()
			self.back.namepanel.Cname:SetContentAlignment(5)
			self.back.namepanel.Cname:Center()
			self.back.namepanel.Cname.Think = function(this)
				this:SetText(LocalPlayer():Name())
				--this:SetSize(string.len(LocalPlayer():Name()),50)
			end
		end
		-- hook.Run("GetSalaryAmount", LocalPlayer(), nut.faction.indices[LocalPlayer():Team()])
		if (self.back.up.money) then 
			local faction = nut.faction.indices[LocalPlayer():Team()]
			self.back.up.money:SetText(char:getMoney().." $   -   " .. ((faction.pay or 0) + math.Round((faction.pay or 0) * (LocalPlayer():getNetVar("rank",1)/(#(SCHEMA.RanksData[faction.ranktable].ranks))),0) or 0) .."$/Ч   -   На счету: " .. char:getData("CharSalary",0).." $")
		end

		if (self.back.up.faction) then
			-- local Rtable = nut.faction.indices[LocalPlayer():Team()].ranktable or "Ranksmain"
			-- local rankDesc = SCHEMA.Ranks[Rtable].translate[] -- SCHEMA.RanksData[nut.faction.indices[entity.Team(entity)].ranktable].translate[LocalPlayer():getNetVar("rank",1)]
			self.back.up.faction:SetText(team.GetName(LocalPlayer():Team()) .. " | " ..SCHEMA.RanksData[nut.faction.indices[LocalPlayer():Team()].ranktable].ranks[LocalPlayer():getNetVar("rank",1)].. " - " .. SCHEMA.RanksData[nut.faction.indices[LocalPlayer():Team()].ranktable].translate[LocalPlayer():getNetVar("rank",1)])
			self.back.up.faction:SizeToContents()
		end
		
		if (self.back.up.experience) then
			local LVL, XP = char:getData("LVL",0), char:getData("XP",0)
			self.back.up.experience.xp = XP
			self.back.up.experience.lvl = LVL
			self.back.up.experience:SetText("Ранг: "..self.back.up.experience.lvl .."  |  ".. math.Round( (self.back.up.experience.xp/((self.back.up.experience.lvl+1)*1000))*100, 0).."%")
		end
		
		if (self.back.model) then
            self.back.model:SetModel(LocalPlayer():GetModel())
            if self.back.model.Entity:LookupBone("ValveBiped.Bip01_Head1") then
                local headpos = self.back.model.Entity:GetBonePosition(self.back.model.Entity:LookupBone("ValveBiped.Bip01_Head1"))
                self.back.model:SetLookAt(headpos)
            end
			self.back.model.Entity:SetSkin(LocalPlayer():GetSkin())
			
			for k, v in ipairs(LocalPlayer():GetBodyGroups()) do
				self.back.model.Entity:SetBodygroup(v.id, LocalPlayer():GetBodygroup(v.id))
			end

			local ent = self.back.model.Entity
			if (ent and IsValid(ent)) then
				local mats = LocalPlayer():GetMaterials()
				for k, v in pairs(mats) do
					ent:SetSubMaterial(k - 1, LocalPlayer():GetSubMaterial(k - 1))
				end
			end
		end

		if (self.back.attribspanel.attribs) then
			local boost = char:getBoosts()
			local count = 0
			for k, v in SortedPairsByMemberValue(nut.attribs.list, "name") do
				if v.name != "Стойкость" then
					local attribBoost = 0
					if (boost[k]) then
						for _, bValue in pairs(boost[k]) do
							attribBoost = attribBoost + bValue
						end
					end

					local bar = self.back.attribspanel.attribs:Add("nutAttribBar")
					bar:Dock(TOP)
					bar:DockMargin(10, 5, 5, 0)
					bar:SetTall(20)
					count = count + 1

					local attribValue = char:getAttrib(k, 0)
					if (attribBoost) then
						bar:setValue(attribValue - attribBoost or 0)
					else
						bar:setValue(attribValue)
					end

					local maximum = v.maxValue or nut.config.get("maxAttribs", 30)
					local percentage = (attribValue / maximum) * 100
					bar:setMax(maximum)
					bar:setReadOnly()
					bar:setText(Format("%s [ %.1f", L(v.name), percentage) .. "% ]" ) --, maximum, attribValue/maximum*100))
					--bar:SetFont("menu_22")
					if (attribBoost) then
						bar:setBoost(attribBoost)
					end
				end
			end
			
			self.back.attribspanel.Paint = function(s,w,h)
				-- surface.SetDrawColor(0, 0, 0, 200)
				-- surface.DrawRect(0, 0, w, h)
				
				surface.SetDrawColor(Color(255, 255, 255, 255))
				surface.SetMaterial(Material("hud/LINE_desc_2.png"))
				surface.DrawTexturedRect(2, 0, 2, count*25)
						
			end
		end

		hook.Run("OnCharInfoSetup", self)
	end

	function PANEL:Paint(w, h)
	end
vgui.Register("nutCharInfo", PANEL, "EditablePanel")

