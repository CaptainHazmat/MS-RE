local PLUGIN = PLUGIN
local Material, vgui, math, timer = Material, vgui, math, timer
local smallFont = "TB_MAINMENU_SMALL"
local menu_12 = "menu_16"
local menu_18 = "menu_16"
local PANEL = {}
local tblMaterials = {}
tblMaterials.background = Material("vgui/background.png")
tblMaterials.selector = Material("vgui/main_menu_button2.png")
tblMaterials.hintwindow = Material("vgui/menu_test.png")
tblMaterials.textentry = Material("vgui/main_menu_button2.png")
tblMaterials.charnameFrame = Material("vgui/private_bussiness.png")
tblMaterials.attribnameFrame = Material("vgui/skills.png")
tblMaterials.menubelow = Material("vgui/empty.png")
tblMaterials.ramka = Material("vgui/ramka.png")
tblMaterials.had = Material("vgui/character.png")

-- ИКОНКИ
tblMaterials.exit = Material("vgui/exit.png")
tblMaterials.create = Material("vgui/create.png")
tblMaterials.discord = Material("vgui/discord.png")
tblMaterials.content = Material("vgui/content.png")
tblMaterials.load = Material("vgui/load.png")


-- Надпись сервера
tblMaterials.servername = Material("vgui/server_name.png")
-- Надпись TB.LAB
tblMaterials.tblab = Material("vgui/tblab.png")
-- Линия , че не понятного ?!?!?!
tblMaterials.line = Material("vgui/line.png")


local lerpDuration = 0.1
local lerpTarget
local lerpOrigin
local lerpStart
local selectorY
local selectorH
local selectorOffset

local function COSerp(fraction, origin, target)
	local fraction2 = (1 - math.cos(fraction * math.pi)) / 2

	return origin * (1 - fraction2) + (target * fraction2)
end

local function paintDPanel(s, w, h)
	nut.util.drawBlur(s, 2)
	

	surface.SetDrawColor(0, 0, 0, 0)
	surface.DrawRect(0, 0, w, h)

	surface.SetDrawColor(color_white)
	surface.SetTextColor(Color(210, 50, 50))
	surface.SetMaterial(tblMaterials.hintwindow)
	surface.DrawTexturedRect(0, 0, w, h)
end

local function paintDPanel2(s, w, h)
	
	surface.SetDrawColor(0, 0, 0, 0)
	surface.DrawRect(0, 0, w, h)

	surface.SetDrawColor(color_white)
	surface.SetTextColor(Color(210, 50, 50))
end

local function paintDtextEntry(s, w, h)
	
	surface.SetDrawColor(0, 0, 0, 0)
	surface.DrawRect(0, 0, w, h)

	surface.SetDrawColor(color_white)
	surface.SetTextColor(Color(210, 50, 50))
	surface.SetMaterial(tblMaterials.textentry)
	surface.DrawTexturedRect(0, 0, w, h)
	
	s:DrawTextEntryText(color_white, color_white, color_white)
	
end

local function AddHeader(text, parent)
	local header = parent:Add("DLabel")
	header:Dock(TOP)
	header:DockMargin(20, 20, 2, 2)
	header:SetContentAlignment(1)
	header:SetTextColor(color_white)
	header:SetText(text)

	return header
end

function PANEL:Init()
	self.scrW, self.scrH = ScrW(), ScrH()

	if (IsValid(nut.gui.char)) then nut.gui.char:Remove() end
	if (IsValid(nut.gui.loading)) then nut.gui.loading:Remove() end
	if (!nut.gui.charLoaded) then nut.gui.charLoaded = true end

	nut.gui.char = self

	self:Dock(FILL)
	self:MakePopup()
	self:Center()
	self:ParentToHUD()
	self.buttons = {}
	self.fadePanels = {}
	

	self:PlayMusic()

	local function createMenu()
		local buttonW, buttonH = self.scrW * 0.2, self.scrH * 0.035
		local buttonX, buttonY = (self.scrW * 0.1) - (buttonW * 0.5), self.scrH * 0.5
		local buttonOffset = self.scrH * 0.05

		self.mainFrame = self:Add("DPanel")
		local i = 0.5
		
		local function AddLabel(name, callback)
			local label = self.mainFrame:Add("DButton")
			label:Dock(TOP)
			label:DockMargin(0,15,0,15)
			label:SetTall(self.scrH * 0.035)
			label:SetAlpha(0)
			label:AlphaTo(255, 0.35, 0)
			
			local textlabel = label:Add("DLabel")
			textlabel:SetColor(color_white)
			textlabel:SetText(name)
			textlabel:Dock(FILL)
			-- textlabel.Paint = function(s, w, h) 
				-- surface.SetDrawColor(Color(255, 255, 255, 255))
				-- surface.SetMaterial(Material("hud/Line_char.png"))
				-- surface.DrawTexturedRect(0, 0, w, h)
			-- end
			
			label:SetText("")
			label.color = Color(255, 255, 255, 0)
			label.OnCursorEntered = function(s)
				surface.PlaySound("tbmw/menuswipe.wav")
			end
			if (callback) then
				label.DoClick = function(s)
					callback(s)
					surface.PlaySound("tbmw/menuclick.wav")
				end
			end
			label.Think = function(s)
				if (s:IsHovered()) then
					label.color = Color(255, 255, 255, 255)
				else
					label.color = Color(255, 255, 255, 0)
				end
			end
			label.Paint = function(s, w, h) 
				surface.SetDrawColor(label.color)
				surface.SetMaterial(Material("hud/Line_char.png"))
				surface.DrawTexturedRect(0, h-4, w, 2)
			end
			i = i + 0.32
			self.buttons[#self.buttons + 1] = label
			return label
		end

		local function ClearAllButtons(callback)
			buttonX, buttonY = (self.scrW * 0.185) - (buttonW * 0.5), self.scrH * 0.44
			local i = 0
			local max = table.Count(self.buttons)
			for k, v in pairs(self.buttons) do
				local reachedMax = i == (max - 1)
				v:AlphaTo(0, 0.3, 0, function()
					if (reachedMax and callback) then
						callback()
					end
					v.noClick = true
					v:Remove()
				end)
				i = i + 1
			end
			self.buttons = {}
		end

		local function CreateReturnButton()
			AddLabel("Назад", function()
				for k, v in pairs(self.fadePanels) do
					if (IsValid(v)) then
						v:AlphaTo(0, 0.1, 0, function()
							v:Remove()
						end)
					end
				end
				ClearAllButtons(function()
					CreateMainButtons()
				end)
			end)
		end
		
		self.mainFrame:SetAlpha(0)
		self.mainFrame:AlphaTo(255, 0.4, 0.4)
		self.mainFrame:Dock(LEFT)
		self.mainFrame:DockMargin(self.scrW/20, self.scrH/3, 0, self.scrH/4)
		self.mainFrame:SetWide(self.scrW/6)
		self.mainFrame.Paint = function( self, w, h )
			-- surface.SetDrawColor(255, 255, 255, 10)
			-- surface.SetMaterial(tblMaterials.selector)
			-- surface.DrawTexturedRect(0, 0, w, h)
		end
		
		function CreateMainButtons()
			local count = 0
			for k, v in pairs(nut.faction.teams) do
				if (nut.faction.hasWhitelist(v.index)) then
					count = count + 1
				end
			end

			local maxChars = hook.Run("GetMaxPlayerCharacter", LocalPlayer()) or nut.config.get("maxChars", 5)
			if (count > 0 and #nut.characters < maxChars and hook.Run("ShouldMenuButtonShow", "create") != false) then
				AddLabel("Новая история", function() ------- создание персонажа ----------------
				
					ClearAllButtons(function()
						
						local charcreate = self:Add("DPanel")
						charcreate:SetPos(0,0)
						charcreate:SetSize(ScrW(),ScrH())
						charcreate:SetAlpha(0)
						charcreate:AlphaTo(255, 1, 0)
						charcreate.Paint = function(s, w, h) 
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/main.png"))
							surface.DrawTexturedRect(0, 0, w, h)
							
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/sflogo.png"))
							surface.DrawTexturedRect(64, ScrH()-128, 54, 41)
						end
						
						local characterFrame2 = charcreate:Add("DPanel")
						characterFrame2:Dock(FILL)
						characterFrame2:DockMargin(self.scrW/3, self.scrH/8, self.scrW/3, self.scrH/8)
						characterFrame2:SetAlpha(0)
						characterFrame2:AlphaTo(255, 0.4, 0.4)
						characterFrame2.Paint = function(s, w, h) end
						local charframew, charframeh = self.scrW/3 , (self.scrH*3)/4
						-------------------------------------------------------
							local buttonscreateframe = characterFrame2:Add("DPanel")
							buttonscreateframe:Dock(BOTTOM)
							buttonscreateframe:DockMargin(10, 5, 10, 10)
							buttonscreateframe:SetSize(characterFrame2:GetWide(), 50)
							buttonscreateframe.Paint = function(s, w, h) end
						
							local createB = buttonscreateframe:Add("DButton")
							createB:Dock(LEFT)
							createB:DockMargin(0,0,0,0)
							createB:SetTall(50)
							createB:SetWide((charframew/2)-50)
							createB:SetAlpha(0)
							createB:AlphaTo(255, 0.35, 0)
							
							local textcreateB = createB:Add("DLabel")
							textcreateB:SetColor(color_white)
							textcreateB:SetContentAlignment(5)
							textcreateB:SetText("Создать")
							textcreateB:Dock(FILL)
							
							createB:SetText("")
							createB.color = Color(106, 29, 21, 255)
							createB.OnCursorEntered = function(s)
								surface.PlaySound("tbmw/menuswipe.wav")
							end
							
							createB.Think = function(s)
								if (s:IsHovered()) then
									createB.color = Color(232, 7, 89, 255)
								else
									createB.color = Color(232, 7, 89, 255)
								end
							end
							createB.Paint = function(s, w, h) 
								surface.SetDrawColor(createB.color)
								surface.DrawRect(0, 0, w, h)
								-- surface.SetDrawColor(createB.color)
								-- surface.SetMaterial(Material("hud/Line_char.png"))
								-- surface.DrawTexturedRect(0, h-4, w, 2)
							end
							
							
							
							local backB = buttonscreateframe:Add("DButton")
							backB:Dock(RIGHT)
							--backB:DockMargin(100,0,0,0)
							backB:SetTall(50)
							backB:SetWide((charframew/2)-50)
							backB:SetAlpha(0)
							backB:AlphaTo(255, 0.35, 0)
							
							local textbackB = backB:Add("DLabel")
							textbackB:SetColor(color_white)
							textbackB:SetContentAlignment(5)
							textbackB:SetText("Назад")
							textbackB:Dock(FILL)
							
							backB:SetText("")
							backB.color = Color(106, 29, 21, 255)
							backB.OnCursorEntered = function(s)
								surface.PlaySound("tbmw/menuswipe.wav")
							end
							
							backB.Think = function(s)
								if (s:IsHovered()) then
									backB.color = Color(232, 7, 89, 255)
								else
									backB.color = Color(232, 7, 89, 255)
								end
							end
							backB.Paint = function(s, w, h) 
								surface.SetDrawColor(backB.color)
								surface.DrawRect(0, 0, w, h)
								-- surface.SetDrawColor(createB.color)
								-- surface.SetMaterial(Material("hud/Line_char.png"))
								-- surface.DrawTexturedRect(0, h-4, w, 2)
							end
							
						---------------------------------------------------------
						local descunder = characterFrame2:Add("DPanel")
						descunder:Dock(BOTTOM)
						descunder:DockMargin(10, 5, 10, 10)
						descunder:SetSize(characterFrame2:GetWide() - 100, 160)
						descunder.Paint = function(s, w, h) 
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/LINE_DESC.png"))
							surface.DrawTexturedRect(0, 4, w, 2)
							
							surface.SetDrawColor(Color(65, 65, 65, 255))
							surface.DrawRect(0, 10, w, h)
						end
						
						descunder.desc = descunder:Add("DTextEntry")
						descunder.desc:Dock(FILL)
						descunder.desc:DockMargin(charframew/6, 12, charframew/6, 0)
						descunder.desc:SetAllowNonAsciiCharacters(true)
						descunder.desc:SetText("")
						descunder.desc:SetTextColor( color_white )
						descunder.desc:SetMultiline(true)
						descunder.desc:SetPaintBackgroundEnabled(false)
						descunder.desc:SetPaintBackground(false)
						descunder.desc:SetEnterAllowed(false)
						descunder.desc:SetDrawLanguageID( false )
						descunder.desc:SetTooltip("Описание вашего персонажа (минимум 4 символа).")
						
						local header = characterFrame2:Add("DLabel")
						header:Dock(BOTTOM)
						header:DockMargin(20, 5, 2, 5)
						header:SetContentAlignment(5)
						header:SetTextColor(color_white)
						header:SetText("Описание (обязательно)")
						
						---------------------------------------------------------
						local descunder2 = characterFrame2:Add("DPanel")
						descunder2:Dock(BOTTOM)
						descunder2:DockMargin(charframew/4, 5, charframew/4, 5)
						descunder2:SetTall(50)
						descunder2.Paint = function(s, w, h) 
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/LINE_DESC.png"))
							surface.DrawTexturedRect(0, 2, w, 2)
							
							surface.SetDrawColor(Color(65, 65, 65, 255))
							surface.DrawRect(0, 6, w, h)
						end
						
						descunder2.name = descunder2:Add("DTextEntry")
						descunder2.name:Dock(TOP)
						descunder2.name:DockMargin(0, 2, 0, 0)
						
						descunder2.name:SetAllowNonAsciiCharacters(true)
						descunder2.name:SetSize(characterFrame2:GetWide(), 40)
						descunder2.name:SetText("")
						descunder2.name:SetTextColor( color_white )
						descunder2.name:SetPaintBackgroundEnabled(false)
						descunder2.name:SetPaintBackground(false)
						descunder2.name:SetEnterAllowed(false)
						descunder2.name:SetDrawLanguageID( false )
						descunder2.name:SetTooltip("Позывной вашего персонажа формата\" Номер Позывной\"")
						
						local header = characterFrame2:Add("DLabel")
						header:Dock(BOTTOM)
						header:DockMargin(characterFrame2:GetWide()/4, 20, characterFrame2:GetWide()/4, 10)
						header:SetContentAlignment(5)
						header:SetTextColor(color_white)
						header:SetText("Номер | Позывной")
						---------------------------------------------------------
						local buttonleft = characterFrame2:Add("DButton")
						buttonleft:Dock(LEFT)
						buttonleft:DockMargin(5,5,0,5)
						buttonleft:SetColor(color_white)
						buttonleft:SetText("<")
						buttonleft.color = Color(55, 55, 55, 0)
						buttonleft.Think = function(s)
							if (s:IsHovered()) then
								buttonleft.color = Color(55, 55, 55, 30)
							else
								buttonleft.color = Color(55, 55, 55, 0)
							end
						end
						buttonleft.Paint = function(s, w, h) 
							surface.SetDrawColor(buttonleft.color)
							surface.DrawRect(0, 0, w, h)
						
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/LINE_desc_2.png"))
							surface.DrawTexturedRect(w-4, 0, 2, h)
						end
						
						local buttonright = characterFrame2:Add("DButton")
						buttonright:Dock(RIGHT)
						buttonright:DockMargin(0,5,5,5)
						buttonright:SetColor(color_white)
						buttonright:SetText(">")
						buttonright.color = Color(55, 55, 55, 0)
						buttonright.Think = function(s)
							if (s:IsHovered()) then
								buttonright.color = Color(55, 55, 55, 30)
							else
								buttonright.color = Color(55, 55, 55, 0)
							end
						end
						buttonright.Paint = function(s, w, h) 
							surface.SetDrawColor(buttonright.color)
							surface.DrawRect(0, 0, w, h)
						
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/LINE_desc_2.png"))
							surface.DrawTexturedRect(2, 0, 2, h)
						end

						local modelPanel = characterFrame2:Add("DPanel")
						modelPanel:Dock(FILL)
						modelPanel:DockMargin(15, 15, 15, 15)
						modelPanel.payload = {}
						modelPanel.Paint = function( self, w, h )
							surface.SetDrawColor(0, 0, 0, 100)
							surface.DrawRect(0, 0, w, h)
						end
						
						local faction = nut.faction.indices[FACTION_START]
						
						modelPanel.model = modelPanel:Add("nutModelPanel")
						modelPanel.model:SetModel(faction.models[1])
						modelPanel.payload.model = faction.models[1]
						modelPanel.modelnum = 1
						modelPanel.model:Dock(FILL)
						modelPanel.model:DockMargin(5, 5, 5, 5)
						modelPanel.model:SetFOV(20)		
						modelPanel.model.PaintModel = modelPanel.model.Paint
						modelPanel.model:SetCursor("none")
						modelPanel.model.Paint = function(this, w, h)
							local color = this.teamColor or color_black

							this:PaintModel(w, h)
							
						end
						if modelPanel.model.Entity:LookupBone("ValveBiped.Bip01_Head1") then
							local headpos = modelPanel.model.Entity:GetBonePosition(modelPanel.model.Entity:LookupBone("ValveBiped.Bip01_Head1"))
							modelPanel.model:SetLookAt(headpos)
						end
						modelPanel.model.enableHook = false
						modelPanel.model.copyLocalSequence = false
						
						buttonleft.DoClick = function(s)
							modelPanel.model:SetModel(faction.models[math.Clamp(modelPanel.modelnum-1, 1, #faction.models)])
							modelPanel.modelnum = math.Clamp(modelPanel.modelnum-1, 1, #faction.models)
							modelPanel.payload.model = faction.models[modelPanel.modelnum]
						end
						
						buttonright.DoClick = function(s)
							modelPanel.model:SetModel(faction.models[math.Clamp(modelPanel.modelnum+1, 1, #faction.models)])
							modelPanel.modelnum = math.Clamp(modelPanel.modelnum+1, 1, #faction.models)
							modelPanel.payload.model = faction.models[modelPanel.modelnum]
						end
						local attribspayload = {}
						for k, v in SortedPairsByMemberValue(nut.attribs.list, "name") do
							attribspayload[k] = 0
						end
						createB.DoClick = function(s)
								local payload = {}
								payload["faction"] = FACTION_START
								payload["name"] = descunder2.name:GetText()
								payload["desc"] = descunder.desc:GetText() or "Неизвестно"
								payload["model"] = modelPanel.modelnum
								payload["attribs"] = attribspayload
								netstream.Hook("charAuthed", function(fault, ...)
									timer.Remove("nutCharTimeout")
									if (type(fault) == "string") then return end
									if (type(fault) == "table") then nut.characters = fault end
								end)
								timer.Create("nutCharTimeout", 20, 1, function()
									return ErrorNoHalt("Проблемка...")
								end)
								netstream.Start("charCreate", payload)
								modelPanel:Remove()
								charcreate:AlphaTo(0, 1, 0)
								timer.Simple(1, function()
									charcreate:Remove()
									CreateMainButtons()
								end)
							end
						
						backB.DoClick = function(s)
							charcreate:AlphaTo(0, 1, 0)
							modelPanel:Remove()
							timer.Simple(1, function()
								charcreate:Remove()
								CreateMainButtons()
							end)
						end
					end)
				end)
			end

			if (#nut.characters > 0 and hook.Run("ShouldMenuButtonShow", "load") != false) then
				AddLabel("Мои истории", function() 
				
					local function createchose()
					-------------------------------------------------
						local id 
						
						local charchoose = self:Add("DPanel")
						charchoose:SetPos(0,0)
						charchoose:SetSize(ScrW(),ScrH())
						charchoose:SetAlpha(0)
						charchoose:AlphaTo(255, 1, 0)
						charchoose.Paint = function(s, w, h) 
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/main.png"))
							surface.DrawTexturedRect(0, 0, w, h)
							
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/sflogo.png"))
							surface.DrawTexturedRect(64, ScrH()-128, 54, 41)
						end
					-------------------------------------------------	
						local characterFrame1 = charchoose:Add("DPanel")
						characterFrame1:Dock(FILL)
						characterFrame1:DockMargin(0, 0, self.scrW*0.75, 0)
						characterFrame1:SetAlpha(0)
						characterFrame1:AlphaTo(255, 0.4, 0.4)
						characterFrame1.Paint = function(s, w, h) 
							surface.SetDrawColor(Color(200, 200, 200, 0))
							surface.DrawRect(0, 0, w, h)
						end	
						local buttonscreateframe = characterFrame1:Add("DPanel")
						buttonscreateframe:Dock(FILL)
						buttonscreateframe:DockMargin(10, self.scrH*0.3, 10, self.scrH*0.3)
						buttonscreateframe.Paint = function(s, w, h) 
							surface.SetDrawColor(Color(200, 200, 200, 0))
							surface.DrawRect(0, 0, w, h)
						end	
						
						
						
					-------------------------------------------------
						local characterFrame2 = charchoose:Add("DPanel")
						characterFrame2:Dock(FILL)
						characterFrame2:DockMargin(self.scrW*0.30, self.scrH*0.30, self.scrW*0.20, self.scrH*0.30)
						characterFrame2:SetAlpha(0)
						characterFrame2:AlphaTo(255, 0.4, 0.4)
						characterFrame2.Paint = function(s, w, h) 
							-- surface.SetDrawColor(Color(200, 200, 200, 255))
							-- surface.DrawRect(0, 0, w, h)
						end
					
						characterFrame2.model = characterFrame2:Add("nutModelPanel")
						characterFrame2.model:Dock(FILL)
						characterFrame2.model:DockMargin(10, 10, self.scrW*0.32, 20)
						characterFrame2.model:SetModel("models/error.mdl")
						characterFrame2.model:SetFOV(10)		
						characterFrame2.model.PaintModel = characterFrame2.model.Paint
						characterFrame2.model:SetCursor("none")
						characterFrame2.model.Paint = function(this, w, h)
							local color = this.teamColor or color_black
							this:PaintModel(w, h)
						end
						
						local InfoFrame = characterFrame2:Add("DPanel")
						InfoFrame:Dock(FILL)
						InfoFrame:DockMargin(self.scrW*0.19, 10, 10, 20)
						InfoFrame.Paint = function(s,w,h)
						end
						InfoFrame.rank = InfoFrame:Add("DLabel")
						InfoFrame.rank:Dock(TOP)
						InfoFrame.rank:DockMargin(15, 5, 5, 0)
						InfoFrame.rank:SetTall(50)
						InfoFrame.rank:SetTextColor(Color(232, 7, 89, 255))
						InfoFrame.rank:SetExpensiveShadow(1, Color(0, 0, 0, 100))
						InfoFrame.rank:SetContentAlignment(4)
						
						InfoFrame.underdesc = characterFrame2:Add("DPanel")
						InfoFrame.underdesc:Dock(FILL)
						InfoFrame.underdesc:DockMargin(self.scrW*0.19, 10, 10, 20)
						InfoFrame.underdesc.Paint = function(s,w,h)
							surface.SetDrawColor(Color(255, 255, 255, 255))
							surface.SetMaterial(Material("hud/LINE_desc_2.png"))
							surface.DrawTexturedRect(2, 0, 2, h)
						end
						
						InfoFrame.underdesc.desc = InfoFrame:Add("DTextEntry")
						InfoFrame.underdesc.desc:Dock(FILL)
						InfoFrame.underdesc.desc:DockMargin(15, 0, 0, 0)
						InfoFrame.underdesc.desc:SetAllowNonAsciiCharacters(true)
						InfoFrame.underdesc.desc:SetText("")
						InfoFrame.underdesc.desc:SetTextColor( color_white )
						InfoFrame.underdesc.desc:SetMultiline(true)
						InfoFrame.underdesc.desc:SetPaintBackgroundEnabled(false)
						InfoFrame.underdesc.desc:SetPaintBackground(false)
						InfoFrame.underdesc.desc:SetEnterAllowed(false)
						InfoFrame.underdesc.desc:SetDrawLanguageID( false )
						InfoFrame.underdesc.desc:SetEditable( false )
					-------------------------------------------------
						
						local bottom = characterFrame2:Add("DPanel")
						bottom:Dock(BOTTOM)
						bottom:SetTall(60)
						bottom:SetDrawBackground(true)
						bottom.Paint = function(s,w,h)
							draw.RoundedBox( 2, 0, 0, w, h, Color( 255, 255, 255, 0 ) ) -- Draw a red box instead of the frame 
							draw.RoundedBox( 2, 0, 0, 410, 30, Color( 255, 0, 0, 0 ) )
						end
						bottom.choose = bottom:Add("DButton")
						bottom.choose:Dock(LEFT)
						bottom.choose:DockMargin(10, -4, 2, 10)
						bottom.choose:SetWide(self.scrW*0.20)
						bottom.choose:SetTextColor(color_white)
						bottom.choose:SetExpensiveShadow(1, Color(0, 0, 0, 0))
						bottom.choose:SetText("      " .. " Выбрать " .. "      ")
						bottom.choose.color = Color(106, 29, 21, 0)
						bottom.choose.Think = function(s)
							if (s:IsHovered()) then
								bottom.choose.color = Color(232, 7, 89, 255)
							else
								bottom.choose.color = Color(232, 7, 89, 255)
							end
						end
						bottom.choose.Paint = function(s, w, h) 
							surface.SetDrawColor(bottom.choose.color)
							surface.DrawRect(0, 0, w, h)
						end
						bottom.choose.DoClick = function(s)
							if ((self.nextUse or 0) < CurTime()) then
								self.nextUse = CurTime() + 1
							else
								return
							end
							local status, result = hook.Run("CanPlayerUseChar", client, nut.char.loaded[id])

							if (status == false) then
								if (result:sub(1, 1) == "@") then
									nut.util.notifyLocalized(result:sub(2))
								else
									nut.util.notify(result)
								end

								return
							end
							if (id) then
								self:Remove()
								local curChar = LocalPlayer():getChar() and LocalPlayer():getChar():getID()
								netstream.Hook("charLoaded", function()
									if (IsValid(darkness)) then
										darkness:AlphaTo(0, 5, 0.5, function()
											darkness:Remove()
										end)
									end
									if (curChar != id) then
										hook.Run("CharacterLoaded", nut.char.loaded[id])
									end
								end)
								netstream.Start("charChoose", id)
							end
						end
						
						bottom.delete = bottom:Add("DButton")
						bottom.delete:Dock(RIGHT)
						bottom.delete:DockMargin(-4, -4, 10, 10)
						bottom.delete:SetTextColor(color_white)
						bottom.delete:SetExpensiveShadow(1, Color(0, 0, 0, 0))
						bottom.delete:SetText("      " .. " Удалить " .. "      " )
						bottom.delete.color = Color(106, 29, 21, 0)
						bottom.delete.Think = function(s)
							if (s:IsHovered()) then
								bottom.delete.color = Color(232, 7, 89, 255)
							else
								bottom.delete.color = Color(232, 7, 89, 255)
							end
						end
						bottom.delete.Paint = function(s, w, h) 
							surface.SetDrawColor(bottom.delete.color)
							surface.DrawRect(0, 0, w, h)
						end
						bottom.delete:SetWide(self.scrW*0.20)
						
						self.characters = {}
						
						local function SetupCharacter(character)
                            if (id != character:getID()) then
                                    characterFrame2.model:SetModel(character:getModel())
                                    if characterFrame2.model.Entity:LookupBone("ValveBiped.Bip01_Head1") then
                                        local headpos = characterFrame2.model.Entity:GetBonePosition(characterFrame2.model.Entity:LookupBone("ValveBiped.Bip01_Head1"))
                                        characterFrame2.model:SetLookAt(headpos)
                                    end
                                local lvl = character:getData("LVL", 0)
                                InfoFrame.rank:SetText("Ранг: "..character:getData("LVL",0))
                                InfoFrame.underdesc.desc:SetText(character:getDesc())
                                id = character:getID()
                            end
                        end

						local function SetupCharList()
							local first = true
							characterFrame2.model:Clear()
							characterFrame2.model:AlphaTo(255, 0.5, 0.5)
							local pupchar = buttonscreateframe:Add("DPanel")
							pupchar:Dock(TOP)
							pupchar:DockMargin(0,15,0,15)
							pupchar:SetTall(self.scrH * 0.055)
							pupchar.Paint = function(s, w, h) 
								surface.SetDrawColor(Color(255,255,255,255))
								surface.SetMaterial(Material("hud/Line_char.png"))
								surface.DrawTexturedRect(0, h-4, w, 2)
							end
							
							pupchar.label = pupchar:Add("DLabel")
							pupchar.label:SetColor(color_white)
							pupchar.label:SetText("Персонажи")
							pupchar.label:Dock(FILL)
							pupchar.label:SetContentAlignment(5)
							
							for k, v in ipairs(nut.characters) do
								local character = nut.char.loaded[v]
								if (character) then
									local label = buttonscreateframe:Add("DButton")
									label:Dock(TOP)
									label:DockMargin(0,15,0,15)
									label:SetTall(self.scrH * 0.055)
									label:SetAlpha(0)
									label:AlphaTo(255, 0.35, 0)
									
									local textlabel = label:Add("DLabel")
									textlabel:SetColor(color_white)
									textlabel:SetText(character:getName())
									textlabel:Dock(FILL)
									textlabel:SetContentAlignment(5)
									label.char = character
									label:SetText("")
									label.color = Color(136, 29, 21, 255)
									label.OnCursorEntered = function(s)
										surface.PlaySound("tbmw/menuswipe.wav")
									end
									label.DoClick = function(s)
										SetupCharacter(label.char)
										id = character:getID()
										surface.PlaySound("tbmw/menuclick.wav")
									end
									label.Think = function(s)
										if (s:IsHovered()) then
											label.color = Color(232, 7, 89, 255)
										else
											label.color = Color(232, 7, 89, 0)
										end
									end
									label.Paint = function(s, w, h) 
										surface.SetDrawColor(label.color)
										surface.DrawRect(0, 0, w, h)
									end
								
									if (first) then
										SetupCharacter(label.char)
										first = nil
									end
									self.characters[#self.characters + 1] = {label = label, id = character:getID()}
								end
							end
							local backB = buttonscreateframe:Add("DButton")
							backB:Dock(TOP)
							backB:SetAlpha(0)
							backB:AlphaTo(255, 0.35, 0)
							
							local textbackB = backB:Add("DLabel")
							textbackB:SetColor(color_white)
							textbackB:SetContentAlignment(5)
							textbackB:SetText("Назад")
							textbackB:Dock(FILL)
							
							backB:SetText("")
							backB.color = Color(106, 29, 21, 0)
							backB.OnCursorEntered = function(s)
								surface.PlaySound("tbmw/menuswipe.wav")
							end
							
							backB.Think = function(s)
								if (s:IsHovered()) then
									backB.color = Color(232, 7, 89, 255)
								else
									backB.color = Color(232, 7, 89, 0)
								end
							end
							backB.Paint = function(s, w, h) 
								surface.SetDrawColor(backB.color)
								surface.DrawRect(0, 0, w, h)
							end
							backB.DoClick = function(s)
								charchoose:AlphaTo(0, 1, 0)
								characterFrame2.model:Remove()
								timer.Simple(1, function()
									charchoose:Remove()
									CreateMainButtons()
								end)
							end
						end
						
						
						SetupCharList()
						
						
						
						bottom.delete.DoClick = function(s)
							local menu = DermaMenu()
								local confirm = menu:AddSubMenu(L("delConfirm", nut.char.loaded[id]:getName()))
								confirm:AddOption(L"no"):SetImage("icon16/cross.png")
								confirm:AddOption(L"yes", function()
									if nut.char.loaded[id]:getMoney() < 3000 then return false end netstream.Start("charDel", id) 
									charchoose:Remove()
									nut.char.loaded[id] = nil
									createchose()
								end):SetImage("icon16/tick.png")
							menu:Open()
						end
					end
					ClearAllButtons( createchose() )
				end)
			end

			AddLabel("Дискорд", function()
				gui.OpenURL("https://discord.gg/Ytw66kJpKx")
			end)

			AddLabel("Контент", function()
				gui.OpenURL("https://steamcommunity.com/sharedfiles/filedetails/?id=3155514697")
			end)
			
			AddLabel("Оригинальное меню", function()
				surface.PlaySound( "ui/button_plastic.wav" )
				self:Remove()
				gui.ActivateGameUI()
			end)	

			AddLabel((!hasCharacter and "Выйти с сервера") or "Продолжить", function()
				if (!hasCharacter) then
					RunConsoleCommand("disconnect")
					return
				end
				self:AlphaTo(0, 0.5, 0, function()
					self:Remove()
				end)
			end)

		end

		CreateMainButtons()
	end	
	if !LocalPlayer():IsValid() then
			-------------------стартовый экран------------------------
	local startFrame= self:Add("DPanel")
	startFrame:SetAlpha(255)
	startFrame:SetSize( self.scrW, self.scrH )
	startFrame.angle = 0
	startFrame.Paint = function( self, w, h )

		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/main.png"))
		surface.DrawTexturedRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/republic_logo.png"))
		surface.DrawTexturedRectRotated( (ScrW()/2),(ScrH()/2)-128 , 512, 512, self.angle )
		
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/Group_1.png"))
		surface.DrawTexturedRect( (ScrW()/2)-259,(ScrH()/1.1)-202 , 518, 148 )
		
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/cop.png"))
		surface.DrawTexturedRect( (ScrW()/2)-172,ScrH()-62 , 344, 31 )
		
		surface.SetDrawColor(Color(255, 255, 255, 25))
		surface.SetMaterial(Material("hud/main_menu.png"))
		surface.DrawTexturedRect(0, 0, w, h)
		
		surface.SetDrawColor(Color(255, 255, 255, 255))
		surface.SetMaterial(Material("hud/sflogo.png"))
		surface.DrawTexturedRect(64, ScrH()-128, 54, 41)
	end
	startFrame.Think = function(s)
		s.angle = s.angle - 0.1
	end
	
	local startB = startFrame:Add("DButton")
		startB:SetPos((ScrW()/2)-128,(ScrH()/2)+128)
		startB:SetSize(256, 64)
		startB:SetColor(color_white)
		startB:SetFont("nutMediumLightFont")
		startB:SetText("Начать игру")
		startB.color = Color(255, 255, 255, 0)
		startB.status = false
		startB:SetAlpha(0)
		startB:AlphaTo(255, 1, 0)
		startB.DoClick = function(s)
			if startB.status == true then return end
			startB.status = true
			if timer.Exists("startB") then timer.Remove("startB") end
			startB:SetAlpha(255)
			startB:AlphaTo(0, 1, 0)
			startFrame:AlphaTo(0, 2, 1)
			timer.Simple(4, function()
				startFrame:Remove()
				createMenu()
			end)
			surface.PlaySound("tbmw/menuclick.wav")
		end
		startB.Paint = function(s, w, h) 
		end
		timer.Create( "startB", 2, 0, function()
			local alpha = startB:GetAlpha() -- 255
			if alpha == 0 then
				startB:AlphaTo(255, 1, 0)
			elseif alpha == 255 then
				startB:AlphaTo(0, 1, 0)
			end
		end )
	----------------------------------------------------------------------
	else
		createMenu()
	end
end

function PANEL:Paint(w, h)
	surface.SetDrawColor(Color(0, 0, 0,235))
	surface.DrawRect(0, 0, w, h)
	local x, y = gui.MousePos()
	
	surface.SetDrawColor(color_white)
	surface.SetMaterial(Material("hud/fill.png"))
	surface.DrawTexturedRect(-0.05 * x, -0.02 * y, w * 1.2, h * 1.02)
	
	--
	surface.SetDrawColor(Color(0, 0, 0,10))
	surface.SetMaterial(Material("hud/static22"))
	surface.DrawTexturedRect(0, 0, w, h)
	
	
	surface.SetDrawColor(color_white)
	surface.SetMaterial(Material("hud/Group_1.png"))
	surface.DrawTexturedRect( (ScrW()/7.5)-259,(ScrH()/3.2)-202 , 518, 148 )
	
	surface.SetDrawColor(Color(255, 255, 255, 255))
	surface.SetMaterial(Material("hud/sflogo.png"))
	surface.DrawTexturedRect(64, ScrH()-128, 54, 41)
end
--[[
function PANEL:PaintOver(w, h)

	local function paintDPanel(s, w, h)
	surface.SetDrawColor(0, 0, 0, 0)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(color_white)
	surface.SetTextColor(Color(210, 50, 50))
	surface.SetMaterial(tblMaterials.create)
	surface.DrawTexturedRect(0, 0, w, h)
	end

	local characterFrame = self:Add("DPanel")
	characterFrame:SetAlpha(0)
	characterFrame:AlphaTo(255, 0.4, 0.4)
	characterFrame:SetSize(600, 480) // scrW / 2.6, scrH / 1.8
	characterFrame:SetPos(dlin , self.scrH / 2.01 - characterFrame:GetTall() / 2)
	characterFrame.Paint = paintDPanel
	
	s:DrawTextEntryText(color_white, color_white, color_white)

end

function PANEL:PaintOver(w, h)
	local selectW = self.scrW * 0.21
	local selectX = (self.scrW * 0.1815) - (selectW * 0.5)

	surface.SetDrawColor(color_white)
	surface.SetMaterial(tblMaterials.selector)
	surface.DrawTexturedRect(selectX, selectorY + 2, selectW, selectorH)
end

function PANEL:SetSelectorY(y)
	if (selectorOffset and isnumber(selectorOffset)) then
		lerpTarget = y - selectorOffset
		lerpOrigin = selectorY or ScrH() * 0.560
		lerpStart = CurTime()
	end
end
]]--
function PANEL:Think()
	if (input.IsKeyDown(KEY_F1) and LocalPlayer():getChar()) then
		self:Remove()
	end

	--[[if (lerpTarget) then
		local fraction = (CurTime() - lerpStart) / lerpDuration

		if (fraction <= 1) then
			selectorY = COSerp(fraction, lerpOrigin, lerpTarget)
		else
			lerpTarget = nil
		end
	end]]--
end

function PANEL:PlayMusic()
	if (nut.menuMusic) then
		nut.menuMusic:Stop()
		nut.menuMusic = nil
	end

	timer.Remove("nutMusicFader")

	local source = nut.config.get("music", ""):lower()
	if (source:find("%S")) then
		local function callback(music, errorID, fault)
			if (music) then
				music:SetVolume(PLUGIN.soundVolume)

				nut.menuMusic = music
				nut.menuMusic:Play()
			else
				MsgC(Color(0, 0, 0), errorID.." ")
				MsgC(color_white, fault.."\n")
			end
		end

		sound.PlayFile("sound/"..source, "noplay", callback)
	end
end
function PANEL:OnRemove()
	if (nut.menuMusic) then
		local fraction = 1
		local start, finish = RealTime(), RealTime() + 5

		timer.Create("nutMusicFader", 0.1, 0, function()
			if (nut.menuMusic) then
				fraction = 1 - math.TimeFraction(start, finish, RealTime())
				nut.menuMusic:SetVolume(fraction * PLUGIN.soundVolume)

				if (fraction <= 0) then
					nut.menuMusic:Stop()
					nut.menuMusic = nil

					timer.Remove("nutMusicFader")
				end
			else
				timer.Remove("nutMusicFader")
			end
		end)
	end
end

vgui.Register("nutCharMenu", PANEL, "EditablePanel")
