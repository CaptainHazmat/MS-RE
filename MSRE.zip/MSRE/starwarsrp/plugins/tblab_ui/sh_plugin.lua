local PLUGIN = PLUGIN

PLUGIN.name = "CaptainHazmat"
PLUGIN.author = "MagicStar"
PLUGIN.desc = ""
PLUGIN.version = 1

local IncludeFiles = {"sh_config.lua"}
for k, v in ipairs(IncludeFiles) do nut.util.include(v) end