local PLUGIN = PLUGIN

PLUGIN.contentURL = nil
PLUGIN.groupURL = nil

PLUGIN.hoverSound = ""
PLUGIN.clickSound = ""

PLUGIN.soundVolume = 0.35