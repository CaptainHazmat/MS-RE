ENT.Type 			= "anim"
ENT.PrintName 		= "Сканер Аномалий"
ENT.Author 			= "Kek1ch"
ENT.Category		= "Warfare ENT"

ENT.Spawnable = true
ENT.AdminSpawnable = true