﻿ITEM.name = "Контейнер с медикаментами"
ITEM.desc = ""
ITEM.price = 5160
ITEM.weight = 0.01

ITEM.model = "models/kek1ch/safe_container.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.iconCam = {
	pos = Vector(238.2673034668, 199, 150.51705932617),
	ang = Angle(25, 220, 0),
	fov = 5.2
}
