﻿ITEM.name = "Костюм Горка-3 (В чехле)"
ITEM.desc = "Отличный костюм за свои деньги. Не пропускает влагу, очень прочный. Может, он даже переоценен, но всё равно пользуется большим спросом. \n\nХАРАКТЕРИСТИКИ: \n-квестовый предмет"
ITEM.price = 3521
ITEM.exRender = false
ITEM.weight = 0.12

ITEM.model = "models/kek1ch/conventer_grenade_box.mdl"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	pos = Vector(160.00798034668, 134.35333251953, 100.5),
	ang = Angle(25, 220, 0),
	fov = 7
}
