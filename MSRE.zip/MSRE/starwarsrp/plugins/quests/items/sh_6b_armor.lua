ITEM.name = "Бронежилет 6б4-23-1"
ITEM.desc = "Не самая новая модель бронежилета, но до сих поря актуальны. Скорее всего, в нее вставлены бронепластины 5а класса. Отличная вещь. \n\nХАРАКТЕРИСТИКИ: \n-квестовый предмет"
ITEM.price = 24341
ITEM.exRender = false
ITEM.weight = 0.12

ITEM.model = "models/hardbass/happy_armor_6b.mdl"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	pos = Vector(290.73440551758, 243.59828186035, 189),
	ang = Angle(25, 220, 0),
	fov = 3.2,
}
