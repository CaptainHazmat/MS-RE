﻿ITEM.name = "Бартыханчик (Мертв)"
ITEM.desc = "Пиздец я долбаеб, нахуй я ему шею сверунл? Ладно, скажу, что он уже была мертва. \n\nХАРАКТЕРИСТИКИ: \n-квестовый предмет"
ITEM.price = 310
ITEM.exRender = false
ITEM.weight = 0.12

ITEM.model = "models/wick/rat/wick_rat.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	pos = Vector(0, 200, 5),
	ang = Angle(0, 270, -32.101909637451),
	fov = 8.5987261146497
}

