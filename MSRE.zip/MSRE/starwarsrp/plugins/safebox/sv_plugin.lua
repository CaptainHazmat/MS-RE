local PLUGIN = PLUGIN

function PLUGIN:saveBox()
	local data = {}

	for k, v in ipairs(ents.FindByClass("nut_safebox")) do
		data[#data + 1] = {v:GetPos(), v:GetAngles(), v:GetModel()} -- money = v:getMoney()
	end

	self:setData(data)
end
