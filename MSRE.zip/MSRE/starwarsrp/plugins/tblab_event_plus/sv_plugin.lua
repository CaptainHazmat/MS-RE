local PLUGIN = PLUGIN

local path = "nutscript/"..SCHEMA.folder.."/"
local filename = "eventcount.txt"

--SCHEMA.RanksPayment type rank
function PLUGIN:StartEvent(ply,name)
	local CheckTime = math.random(10,20)
	CheckTime = CheckTime*60
	if timer.Exists( "event" ) then timer.Remove("event") end
	-- timer.Create("event", CheckTime, 1, function()
		-- local total = 1000
		-- for k,v in pairs(player.GetAll()) do
			-- if v:getChar() then 
				-- local char = v:getChar()
				-- local CharSalary = char:getData("CharSalary",0)
				
				-- local dataF = nut.faction.indices[char:getFaction()]
				-- local rt = dataF.ranktable or "Ranksmain"
				-- local Rtable = SCHEMA.RanksData[rt]
				-- local rank = char:getData("rank",1)
				-- char:setData("CharSalary",CharSalary+Rtable.salary[rank])
				-- char:setData("CanRaport", true)
				-- ply:notify("От компании получена зарплата в размере: " ..Rtable.salary[rank].."$")
				-- total = total + 1000
				-- hook.Run("OnHourSalary", ply, CharSalary, char:getData("CharSalary",0), Rtable.salary[rank])
			-- end
		-- end
		-- nut.globalvars.set("BaseMoney", nut.globalvars.stored["BaseMoney"] + total)
	-- end)
	Mission.data.name = name
	Mission:UpdateClients()
	ply:notify("Ивент "..name.." запущен!")
	ply:notify(CheckTime.. " Секунд")
end

-- function PLUGIN:GetSalaryAmount(client, faction)
	-- local char = client:getChar()
	-- local rank = char:getData("rank",1)
	-- local tbl = SCHEMA.RanksData[faction.ranktable]
	-- local add = math.Round(faction.pay * (rank/(#tbl.ranks)),0)
	-- local pay = (faction.pay + math.Round(faction.pay * (rank/(#tbl.ranks)),0))
	-- return pay
-- end