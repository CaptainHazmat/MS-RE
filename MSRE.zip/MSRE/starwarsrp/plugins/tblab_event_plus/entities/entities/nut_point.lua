ENT.Type = "anim"
ENT.PrintName = "Цель"
ENT.Author = "Tium"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "NutScript"
ENT.RenderGroup = RENDERGROUP_BOTH

if (SERVER) then
	function ENT:SpawnFunction(client, trace, className)
		if (!trace.Hit or trace.HitSky) then return end

		local ent = ents.Create(className)
		local pos = trace.HitPos + trace.HitNormal * 50
		ent:SetPos(pos)
		ent:Spawn()
		ent:Activate()
		ent:SetMaterial("Models/effects/vol_light001")
		ent:SetColor( Color(255, 255, 255, 0) )
		
		return ent
	end
	
	function ENT:Initialize()
		self:SetModel("models/hunter/misc/sphere025x025.mdl")
		self:PhysicsInit(SOLID_VPHYSICS);
		self:SetMoveType(MOVETYPE_NONE);
		self:SetSolid(SOLID_VPHYSICS);
		self:SetUseType(SIMPLE_USE)
		self:SetMaterial("Models/effects/vol_light001")
		self:SetColor( Color(255, 255, 255, 0) )
		self:DrawShadow( false )
		local physicsObject = self:GetPhysicsObject()

		if (IsValid(physicsObject)) then
			physicsObject:Wake()
		end
	end
	
	function ENT:Think()
		
	end

	function ENT:OnRemove()
	end

	function ENT:Use(activator)
		
	end
else
	function ENT:Draw()
		self:DrawModel()
	end
	
	function ENT:onShouldDrawEntityInfo()
		return true
	end
	
	function ENT:onDrawEntityInfo(alpha)
		-- local position = self:LocalToWorld(self:OBBCenter()):ToScreen()
		-- local x, y = position.x, position.y
		-- halo.Add( {[1] = self}, Color(255,0,0,200), 1, 1, 2 )
		--nut.util.drawText("Цель", x , y, ColorAlpha(color_black, alpha), 1, 1, "nutBigFont", alpha * 0.65)
	end
end